# AI-Driven Intrusion Detection System

A Python-based IDS with a futuristic web frontend:
- Quantum-inspired classification with adaptive thresholding
- Blockchain for secure logging
- Reinforcement Learning for self-adaptation
- Edge computing with detailed real-time traffic analysis
- Time-series prediction for threat intelligence
- Real-time threat visualization with moving graph

## Prerequisites
- Python 3.x
- Libraries: `tensorflow`, `scapy`, `numpy`, `sklearn`, `flask`
- Install: `pip install tensorflow scapy numpy sklearn flask`
- Root privileges for `scapy` (run with `sudo`)

## File Structure
- `main.py`: Flask server and real-time IDS logic
- `templates/index.html`: Cyberpunk dashboard with detailed logs
- `static/style.css`: Futuristic CSS with animations
- `static/script.js`: JS with graph, action effects, and animations
- `static/chart.min.js`: Chart.js (download from https://cdn.jsdelivr.net/npm/chart.js)
- `static/activate.mp3`: Activation sound (provide your own)
- `static/deactivate.mp3`: Deactivation sound (provide your own)
- Other `.py` files: Backend logic

## How to Run
1. Navigate to the project directory.
2. Download Chart.js: `curl -o static/chart.min.js https://cdn.jsdelivr.net/npm/chart.js`
3. Add sound files (`activate.mp3`, `deactivate.mp3`) to `static/` (e.g., from Freesound.org).
4. Run with root privileges: `sudo python main.py`
5. Open `http://localhost:5000` in a browser.
6. Click "Activate" to start real-time analysis, "Deactivate" to stop.

## Notes
- Captures detailed traffic: IPs, MACs, ports, TTL, direction, attack type, threat score, etc.
- Requires an active network interface with traffic.
- Run with `sudo` for `scapy` to access packets.
let running = false;
let chart;
const maxDataPoints = 20;
let dataBuffer = { labels: [], unsafe: [], threatScore: [] }; // Added threatScore for dual-line chart

function startIDS() {
    if (!running) {
        running = true;
        document.getElementById("status").innerText = "Status: Online";
        document.getElementById("status").classList.add("active");

        // Action effects for activation
        const overlay = document.getElementById("action-overlay");
        const wheel = document.getElementById("cyber-wheel");
        overlay.classList.add("active");
        wheel.classList.add("active");
        document.getElementById("activate-sound").play();
        createParticles("activate");
        setTimeout(() => {
            overlay.classList.remove("active");
            wheel.classList.remove("active");
        }, 1000);

        fetch('/start', { method: 'POST' })
            .then(response => response.json())
            .then(data => console.log(data.message))
            .catch(error => console.error("Error starting IDS:", error));
        updateLogs();
    }
}

function stopIDS() {
    if (running) {
        running = false;
        document.getElementById("status").innerText = "Status: Offline";
        document.getElementById("status").classList.remove("active");

        // Action effects for deactivation
        const overlay = document.getElementById("action-overlay");
        const human = document.getElementById("cyber-human");
        overlay.classList.add("active");
        human.classList.add("active");
        document.getElementById("deactivate-sound").play();
        createParticles("deactivate");
        setTimeout(() => {
            overlay.classList.remove("active");
            human.classList.remove("active");
        }, 1500);

        fetch('/stop', { method: 'POST' })
            .then(response => response.json())
            .then(data => console.log(data.message))
            .catch(error => console.error("Error stopping IDS:", error));
    }
}

function updateLogs() {
    if (running) {
        fetch('/logs')
            .then(response => response.json())
            .then(data => {
                console.log("Logs fetched:", data); // Debug log
                document.getElementById("safe-traffic").innerText = data.safe || "No safe traffic logged yet.";
                document.getElementById("unsafe-traffic").innerText = data.unsafe || "No unsafe traffic logged yet.";
                document.getElementById("blockchain").innerText = JSON.stringify(data.blockchain, null, 2);
                document.getElementById("prediction").innerText = data.prediction || "Awaiting data...";
                if (data.prediction && data.prediction.includes("WARNING")) {
                    document.getElementById("prediction").classList.add("alert");
                } else {
                    document.getElementById("prediction").classList.remove("alert");
                }
                updateChart(data.graph || []);
            })
            .catch(error => {
                console.error("Error fetching logs:", error);
                document.getElementById("status").innerText = "Status: Error";
            });
        setTimeout(updateLogs, 1000); // Reduced to 1s for faster updates
    }
}

function updateChart(graphData) {
    const ctx = document.getElementById("trafficChart").getContext("2d");

    // Update buffer with new data
    graphData.forEach(d => {
        dataBuffer.labels.push(d.time);
        dataBuffer.unsafe.push(d.unsafe);
        dataBuffer.threatScore.push(d.threat_score || 0); // Fallback if threat_score missing
    });

    // Keep only the last maxDataPoints
    if (dataBuffer.labels.length > maxDataPoints) {
        dataBuffer.labels = dataBuffer.labels.slice(-maxDataPoints);
        dataBuffer.unsafe = dataBuffer.unsafe.slice(-maxDataPoints);
        dataBuffer.threatScore = dataBuffer.threatScore.slice(-maxDataPoints);
    }

    if (!chart) {
        chart = new Chart(ctx, {
            type: "line",
            data: {
                labels: dataBuffer.labels,
                datasets: [
                    {
                        label: "Intrusion Activity",
                        data: dataBuffer.unsafe,
                        borderColor: "#ff007a",
                        backgroundColor: "rgba(255, 0, 122, 0.2)",
                        borderWidth: 2,
                        pointBackgroundColor: "#00ffcc",
                        pointRadius: 0,
                        fill: false,
                        tension: 0.1
                    },
                    {
                        label: "Threat Score",
                        data: dataBuffer.threatScore,
                        borderColor: "#00ffcc",
                        backgroundColor: "rgba(0, 255, 204, 0.2)",
                        borderWidth: 2,
                        pointBackgroundColor: "#ff007a",
                        pointRadius: 0,
                        fill: false,
                        tension: 0.1
                    }
                ]
            },
            options: {
                animation: { duration: 1000, easing: "linear" },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 1,
                        ticks: { color: "#00ffcc" },
                        grid: { color: "rgba(0, 255, 204, 0.2)" }
                    },
                    x: {
                        ticks: { color: "#00ffcc", maxTicksLimit: 10 },
                        grid: { color: "rgba(0, 255, 204, 0.2)" }
                    }
                },
                plugins: {
                    legend: { labels: { color: "#ff007a" } }
                }
            }
        });
    } else {
        chart.data.labels = dataBuffer.labels;
        chart.data.datasets[0].data = dataBuffer.unsafe;
        chart.data.datasets[1].data = dataBuffer.threatScore;
        chart.update();
    }
}

function createParticles(type) {
    const overlay = document.getElementById("action-overlay");
    for (let i = 0; i < 20; i++) {
        const particle = document.createElement("div");
        particle.className = "particle";
        particle.style.left = `${Math.random() * 100}%`;
        particle.style.top = `${Math.random() * 100}%`;
        particle.style.background = type === "activate" ? "#00ffcc" : "#ff007a";
        overlay.appendChild(particle);
        setTimeout(() => particle.remove(), 1000);
    }
}

function toggleMusic() {
    const music = document.getElementById("bg-music");
    const toggle = document.getElementById("music-toggle");
    if (toggle.checked) {
        music.play().catch(error => console.error("Error playing music:", error));
    } else {
        music.pause();
    }
}

function resetLogs() {
    running = false;
    fetch('/reset', { method: 'POST' })
        .then(response => response.json())
        .then(data => console.log(data.message))
        .catch(error => console.error("Error resetting:", error));
    document.getElementById("status").innerText = "Status: Offline";
    document.getElementById("status").classList.remove("active");
    document.getElementById("safe-traffic").innerText = "No safe traffic logged yet.";
    document.getElementById("unsafe-traffic").innerText = "No unsafe traffic logged yet.";
    document.getElementById("blockchain").innerText = "[]";
    document.getElementById("prediction").innerText = "Awaiting data...";
    document.getElementById("prediction").classList.remove("alert");
    if (chart) {
        dataBuffer.labels = [];
        dataBuffer.unsafe = [];
        dataBuffer.threatScore = [];
        chart.data.labels = [];
        chart.data.datasets[0].data = [];
        chart.data.datasets[1].data = [];
        chart.update();
    }
}

// Initialize music state
document.getElementById("bg-music").volume = 0.5; // Default volume